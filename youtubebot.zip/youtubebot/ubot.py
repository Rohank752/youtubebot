from selenium import webdriver
import os
import time
import configparser
import urllib
from selenium.webdriver.common.keys import Keys

class YoutubeBot:

    def __init__(self, username, password):
       


        self.username = username
        self.password = password
        self.driver = webdriver.Chrome('./chromedriver.exe')
        self.driver.get('https://www.youtube.com/watch?v=r59xYe3Vyks&list=PLS1QulWo1RIbfTjQvTdj8Y6yyq4R7g-Al')
        time.sleep(2)
        submit_button = self.driver.find_elements_by_xpath('/html/body/ytd-app/div/ytd-page-manager/ytd-watch-flexy/div[4]/div[1]/div/ytd-playlist-panel-renderer/div/div[1]/div/div[2]/div[1]/div[1]/ytd-menu-renderer/div/ytd-toggle-button-renderer[1]/a/yt-icon-button/button/yt-icon')
        if len(submit_button) > 0:
            submit_button[0].click()
        

       
        
        
        """self.login()
        self.base_url = 'https://www.youtube.com'
        time.sleep(2)"""


    def uvideo1(self):

        self.driver.execute_script("window.open('https://www.youtube.com/watch?v=r59xYe3Vyks&list=PLS1QulWo1RIbfTjQvTdj8Y6yyq4R7g-Al', 'new_window')")
        time.sleep(2)
        #self.driver.get('https://www.youtube.com/watch?v=r59xYe3Vyks&list=PLS1QulWo1RIbfTjQvTdj8Y6yyq4R7g-Al')
        
       
        self.driver.execute_script("window.open('https://www.youtube.com/watch?v=r59xYe3Vyks&list=PLS1QulWo1RIbfTjQvTdj8Y6yyq4R7g-Al', 'new_window1')")
        time.sleep(2)
        self.driver.execute_script("window.open('https://www.youtube.com/watch?v=r59xYe3Vyks&list=PLS1QulWo1RIbfTjQvTdj8Y6yyq4R7g-Al', 'new_window2')")
        time.sleep(2) 
        self.driver.execute_script("window.open('https://www.youtube.com/watch?v=r59xYe3Vyks&list=PLS1QulWo1RIbfTjQvTdj8Y6yyq4R7g-Al', 'new_window3')")
        time.sleep(2) 
        self.driver.execute_script("window.open('https://www.youtube.com/watch?v=r59xYe3Vyks&list=PLS1QulWo1RIbfTjQvTdj8Y6yyq4R7g-Al', 'new_window4')")
        time.sleep(2) 
        self.driver.execute_script("window.open('https://www.youtube.com/watch?v=r59xYe3Vyks&list=PLS1QulWo1RIbfTjQvTdj8Y6yyq4R7g-Al', 'new_window5')")
        time.sleep(2) 
        self.driver.execute_script("window.open('https://www.youtube.com/watch?v=r59xYe3Vyks&list=PLS1QulWo1RIbfTjQvTdj8Y6yyq4R7g-Al', 'new_window6')")
        time.sleep(2) 
        self.driver.execute_script("window.open('https://www.youtube.com/watch?v=r59xYe3Vyks&list=PLS1QulWo1RIbfTjQvTdj8Y6yyq4R7g-Al', 'new_window7')")
        time.sleep(2) 
        self.driver.execute_script("window.open('https://www.youtube.com/watch?v=r59xYe3Vyks&list=PLS1QulWo1RIbfTjQvTdj8Y6yyq4R7g-Al', 'new_window8')")
        time.sleep(2) 
        self.driver.execute_script("window.open('https://www.youtube.com/watch?v=r59xYe3Vyks&list=PLS1QulWo1RIbfTjQvTdj8Y6yyq4R7g-Al', 'new_window9')")
        time.sleep(2) 
        self.driver.execute_script("window.open('https://www.youtube.com/watch?v=r59xYe3Vyks&list=PLS1QulWo1RIbfTjQvTdj8Y6yyq4R7g-Al', 'new_window10')")
        time.sleep(2)
        self.driver.execute_script("window.open('https://www.youtube.com/watch?v=r59xYe3Vyks&list=PLS1QulWo1RIbfTjQvTdj8Y6yyq4R7g-Al', 'new_window11')")
        time.sleep(2)
        self.driver.execute_script("window.open('https://www.youtube.com/watch?v=r59xYe3Vyks&list=PLS1QulWo1RIbfTjQvTdj8Y6yyq4R7g-Al', 'new_window12')")
        time.sleep(2)
        self.driver.execute_script("window.open('https://www.youtube.com/watch?v=r59xYe3Vyks&list=PLS1QulWo1RIbfTjQvTdj8Y6yyq4R7g-Al', 'new_window13')")
        time.sleep(2)
        self.driver.execute_script("window.open('https://www.youtube.com/watch?v=r59xYe3Vyks&list=PLS1QulWo1RIbfTjQvTdj8Y6yyq4R7g-Al', 'new_window14')")
        time.sleep(2)
       # follow_button = self.driver.find_elements_by_xpath('/html/body/ytd-app/div/ytd-page-manager/ytd-watch-flexy/div[4]/div[1]/div/ytd-playlist-panel-renderer/div/div[1]/div/div[2]/div[1]/div[1]/ytd-menu-renderer/div/ytd-toggle-button-renderer[1]/a/yt-icon-button/button/yt-icon').click() 
       
      

       # follow_button.click()
        time.sleep(2)
        


if __name__ == '__main__':
    u_bot = YoutubeBot('temp_username', 'temp_password')
    time.sleep(2)
    u_bot.uvideo1()
    

    